

//var myHeading = document.querySelector('h1');  /* 获取第一个h1元素*/
//myHeading.textContent =  'Hello world!';
/*
myImage = document.querySelector('img');
myImage.onclick = function(){
	
	myImage.setAttribute('src', 'images\2.jpg');
}*/

var myButton = document.querySelector('button');
var myHeading = document.querySelector('h1');


if(!localStorage.getItem('name')){
	setUserName();
}else{
	 var storedName = localStorage.getItem('name');
	 myHeading.textContent = 'Hello!' + storedName +'!';
}
myButton.onclick = function(){
	setUserName();
}
function setUserName(){
	var myName = prompt('please enter your name.'); //弹出一个对话框，需要用户输入
	localStorage.setItem('name', myName);
	myHeading.textContent = 'Hello!' + myName+'!';
}
